#DIRECTIONS
#Package all reusable code into functions (at least 3 functions total)
#Include at least one loop
#Either read and save from/to a file or use an advanced topic we haven't covered
#Account for erroneous user input(or file input) with try/except statements
#Use at least two different data structures

#IDEA
#jeopardy game but more simple
#three functions: 1) asking user 2)actual question 3) point total
#use file by putting category questions and iterating diff files depending on category

#FUNCTIONS
import os
# ask_user functions checks to see if file name is valid
def ask_user(user_name):
    while True:
        try:
            user_category = input(user_name + ", what category and for how many points do you choose? Enter in the format CategoryNamePointValue.txt ")
            with open(user_category) as file:
                contents = file.readlines()
                os.remove(user_category)
            return contents
            break
        except:
            print("That isn't a valid file name please try again.")
# category_player1 functions asks user1 the question and checks if correct
def category_player1(contents):
    how_many_points = int(input("For how many points? "))
    print(contents[0].strip("\n"))
    user_answer = input("What is your answer? ")
    correct_answer = contents[1].strip("\n")
    user_answer = user_answer.strip("\n")
    if user_answer.lower() == correct_answer.lower():
        print("Thats correct!")
        player1_file = open("player_1.txt","a")
        player1_file.write(str(how_many_points))
        player1_file.write("\n")
    else:
        print("That was incorrect.")
        print("The correct answer is " + correct_answer)
        wrong_answer = 0
        player1_file = open("player_1.txt","a")
        player1_file.write(str(wrong_answer))
        player1_file.write("\n")
    contents.clear()
# category_player2 functions asks user2 the question and checks if correct
def category_player2(contents):
    how_many_points = int(input("For how many points? "))
    print(contents[0].strip("\n"))
    user_answer = input("What is your answer? ")
    correct_answer = contents[1].strip("\n")
    user_answer = user_answer.strip("\n")
    if user_answer.lower() == correct_answer.lower():
        print("Thats correct!")
        player2_file = open("player_2.txt","a")
        player2_file.write(str(how_many_points))
        player2_file.write("\n")
    else:
        print("That was incorrect.")
        print("The correct answer is " + correct_answer)
        wrong_answer = 0
        player2_file = open("player_2.txt","a")
        player2_file.write(str(wrong_answer))
        player2_file.write("\n")
    contents.clear()
# score_calculator calculates the score and says who won
def score_calculator(user_name1, user_name2):
    player1_score = 0
    player1_file = open("player_1.txt","r")
    for num in player1_file:
        num = num.strip()
        player1_score = player1_score + int(num)
    print(user_name1,"score is:",player1_score)
    player2_score = 0
    player2_file = open("player_2.txt","r")
    for num in player2_file:
        num = num.strip()
        player2_score = player2_score + int(num)
    print(user_name2,"score is:",player2_score)
    if player1_score > player2_score:
        print(user_name1 + " won!")
    elif player1_score == player2_score:
        print("It was a tie!")
    else:
        print(user_name2 + "won!")

#ACTUAL CODE
print("Welcome to Jeopardy! I'm your host.")
print("The instructions are fairly simple, you will be given 2 categories for which you have 3 different point options.")
print("The categories are Science and World History")
print("As for point options you have 100, 500, and 1000.")
user_name1 = input("Player1 name: ")
user_name2 = input("Player2 name: ")
contents = ask_user(user_name1)
category_player1(contents)
contents = ask_user(user_name2)
category_player2(contents)
contents = ask_user(user_name1)
category_player1(contents)
contents = ask_user(user_name2)
category_player2(contents)
contents = ask_user(user_name1)
category_player1(contents)
contents = ask_user(user_name2)
category_player2(contents)
score_calculator(user_name1, user_name2)
