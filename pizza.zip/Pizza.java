/**
* The Pizza class represents a pizza with size and topping details
* @author Bandhavya Parvathaneni
* @version 1.0
* @see pizzaDriver
*/
public class Pizza{
    // private member vars
    private String m_size;
    /**
    * a String representation of the size of the pizza
    */
    private int m_cheese;
    /**
    * an int representation of the number of cheese toppings
    */
    private int m_pep;
    /**
    * an int representation of the number of pepperoni toppings
    */
    private int m_veg;
    /**
    * an int representation of the number of vegetarian toppings
    */

    // default constructor
    /**
    * default constructor provides a default input for the attributes of the pizza
    */
    public Pizza() {
      m_size = "";
      m_cheese = 0;
      m_pep = 0;
      m_veg = 0;
    }
    // overloaded constructor
    /**
    * overloaded constructor provides a default input for the attributes of the pizza
    * @param s, n, p, v
    */
    public Pizza(String s, int n, int p, int v){
      m_size = s;
      m_cheese = n;
      m_pep = p;
      m_veg = v;
    }
    // copy constructor
    /*
    * copy constructor copies attributes to a parameter
    * @param s
    */
    public Pizza(Pizza z){
      this.m_size = z.m_size;
      this.m_cheese = z.m_cheese;
      this.m_pep = z.m_pep;
      this.m_veg = z.m_veg;
    }
    //public accessors and mutators
    /*
    * accessor returns a specific value
    * @return m_size
    */
    public String getSize(){
      return m_size;
    }
    /*
    * mutator sets a member value with a certain value
    * @param size
    */
    public void setSize(String size){
      m_size = size;
    }
    /*
    * accessor returns a specific value
    * @return m_cheese
    */
    public int getnumCheese(){
      return m_cheese;
    }
    /*
    * mutator sets a member value with a certain value
    * @param cheese
    */
    public void  setnumCheese(int cheese){
      m_cheese = cheese;
    }
    /*
    * accessor returns a specific value
    * @return m_pep
    */
    public int getnumPep(){
      return m_pep;
    }
    /*
    * mutator sets a member value with a certain value
    * @param pep
    */
    public void  setnumPep(int pep){
      m_pep = pep;
    }
    /*
    * accessor returns a specific value
    * @return m_veg
    */
    public int getnumVeg(){
      return m_veg;
    }
    /*
    * mutator sets a member value with a certain value
    * @param veg
    */
    public void setnumVeg(int veg){
      m_veg = veg;
    }
/*
* calcCost method allows us to calculate the cost given number of toppings
* @return result
*/
    public double calcCost(){
      int result = 0;
      int numToppings = 0;
      numToppings += (m_cheese + m_veg + m_pep);
      if (m_size.equals("Small") || m_size.equals("small")){
        result += 10 + (2 * numToppings);
      }
      else if(m_size.equals("Medium") || m_size.equals("medium")){
        result += 12 + (2 * numToppings);
      }
      else if(m_size.equals("Large") || m_size.equals("large")){
        result += 14 + (2 * numToppings);
      }
      return result;
    }
  }
