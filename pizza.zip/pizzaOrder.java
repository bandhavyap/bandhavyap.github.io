/**
* The pizzaOrder class represents a pizza order
* @author Bandhavya Parvathaneni
* @version 1.0
* @see pizzaDriver
*/
public class pizzaOrder{
  // private member vars
  private Pizza[] m_order = new Pizza[10];
  /**
  * an Array representation of the number and details of pizza in an order
  */
  private int m_numPizzas;
  /**
  * an int representation of the number of the pizzas
  */
  private Object pizza;
  /**
  * an Object representation of the base type pizza
  */
  // default constructor
  /**
  * default constructor provides a default input for the attributes of the pizza
  */
  public pizzaOrder(){
    m_order = new Pizza[1];
    m_order[0] = new Pizza("cheese", 0, 0, 0);
    m_numPizzas = 1;
  }
  // overloaded constructor
  /**
  * overloaded constructor provides a default input for the attributes of the pizza
  * @param m_count
  */
  public pizzaOrder(int m_count){
    m_order = new Pizza[m_count];
    this.m_numPizzas = 0;
  }
  /*
  * addPizza method allows us to adjust the number of pizzas
  * @return result
  */
  public int addPizza(Pizza pizza){
    if(m_numPizzas == m_order.length){
      return -1;
    }
    else{
      m_order[m_numPizzas++] = pizza;
      return 1;
    }
  }
  /*
  * calcTotal method allows us to calculate the total price
  * @return total
  */
  public double calcTotal(){
    double total = 0.0;
    for(int i = 0;i < m_order.length; i++){
      total += m_order[i].calcCost();
      }
      return total;
    }
/*
* toString method allows us to pretty print values
* @return s
*/
  public String toString(){
    String s = "";
    s += "Number of Pizzas: " + m_numPizzas + "\n";
    s += "Total Cost: $" + calcTotal();
    return s;
  }
}
