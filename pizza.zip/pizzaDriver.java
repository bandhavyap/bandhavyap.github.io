public class pizzaDriver{

  public static void main(String[] args){
    Pizza p1 = new Pizza("small", 1, 0, 1);
    Pizza p2 = new Pizza("large", 2, 2, 0);
    Pizza p3 = new Pizza(p2);
    Pizza p4 = new Pizza(p1);
    pizzaOrder m_order = new pizzaOrder(3);
    System.out.println(m_order.addPizza(p1));
    System.out.println(m_order.addPizza(p2));
    System.out.println(m_order.addPizza(p3));
    System.out.println(m_order.addPizza(p4));

    System.out.println(p1.equals(p3));
    System.out.println(m_order);
  }
}
