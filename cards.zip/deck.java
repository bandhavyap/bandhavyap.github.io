import java.util.LinkedList;
import java.util.Random;

public class deck{
  // instanciates LinkedList
  LinkedList<card> m_cards = new LinkedList<card>();

  // default constructor
  public deck(){
    m_cards = new LinkedList<card>();
    // max suit value is 3 & min is 0
    for(int card_suit = 0; card_suit <= 3; card_suit++){
      // max card value is 14 & min is 2
      for(int card_value = 2; card_value <= 14; card_value++){
        m_cards.add(new card(card_value, card_suit));
      }
    }
  }
  // copy constructor
  public deck(deck d){
    m_cards = new LinkedList<card>();
    // deep copy of another card since we use keyword new
    // enhanced for loop
    for(card c: d.m_cards){
      m_cards.add(new card(c));
    }
  }

  // toString method
  public String toString(){
    String s = "";
    // enhanced for loop
    for(int i = 0; i < this.m_cards.size(); i++){
      s += this.m_cards.get(i).toString();
      // uses toString method
      s += "\n";
    }
    return s;
  }

  // size method
  public int size(){
    // use .size() method
    int a = this.m_cards.size();
    return a;
  }

  // deal method
  public card deal(){
    // using random class that we imported
    Random r = new Random();
    int i = r.nextInt(m_cards.size());
    // removes the card
    return m_cards.remove(i);
  }
}
