import java.util.LinkedList;
public class dealer{
  private deck m_deck;

  // default constructor
  public dealer(){
    m_deck = new deck();
  }

  // deals method
  public LinkedList<card> deals(int n){
    LinkedList<card> length = new LinkedList<card>();
    for(int i = 0; i < n; i++){
      if(m_deck.size() > 0){
        length.add(m_deck.deal());
      }
    }
    return length;
  }
  // size method
  public int size(){
    int b = m_deck.size();
    return b;
  }

  // toString method
  public String toString(){
    String sd = "";
    sd += m_deck.toString() + "\n";
    return sd;
  }
}
