import java.util.LinkedList;

public class testCards{
  public static void main(String[] args){
    card c = new card();
    card c1 = new card(11,0);
    card c2 = new card(12, 3);
    card c3 = new card(14, 3);
    System.out.println(c1.toString());
    System.out.println(c2.toString());
    System.out.println(c3.toString());
    deck d = new deck();
    System.out.println(d.toString());
    dealer d_d = new dealer();
    LinkedList<card> cl = d_d.deals(20);
    System.out.println(cl.toString());
  }
}
