public class card{
  // member variabls
  private int card_value;
  private int card_suit;

  // hearts suit
  public static final int HEARTS = 0;
  // spades suit
  public static final int SPADES = 1;
  // clubs suit
  public static final int CLUBS = 2;
  // diamonds suit
  public static final int DIAMONDS = 3;
  // nums
  public static final int TWO = 2;
  public static final int THREE = 3;
  public static final int FOUR = 4;
  public static final int FIVE = 5;
  public static final int SIX = 6;
  public static final int SEVEN = 7;
  public static final int EIGHT = 8;
  public static final int NINE = 9;
  public static final int TEN = 10;
  // jacks
  public static final int JACK = 11;
  // queens
  public static final int QUEEN = 12;
  // kings
  public static final int KING = 13;
  // aces
  public static final int ACE = 14;

  // default constructor
  public card(){
    card_value = 0;
    card_suit = 0;
  }
  // overloaded constructor
  public card(int v, int s){
    card_value = v;
    card_suit = s;
  }

  // copy constructor
  public card(card c){
    this.card_value = c.card_value;
    this.card_suit = c.card_suit;
  }

  // toString method
  public String toString(){
    String suit = "";
    String value = "";

    if (card_suit == 0){
      suit += "Hearts";
    }
    else if(card_suit == 1){
      suit += "Spades";
    }
    else if(card_suit == 2){
      suit += "Clubs";
    }
    else if(card_suit == 3){
      suit += "Diamonds";
    }

    if (card_value == 11){
      value += "Jack ";
    }
    else if(card_value == 12){
      value += "Queen ";
    }
    else if(card_value == 13){
      value += "King ";
    }
    else if(card_value == 14){
      value += "Ace ";
    }
    else if(card_value == 2){
      value += "2 ";
    }
    else if(card_value == 3){
      value += "3 ";
    }
    else if(card_value == 4){
      value += "4 ";
    }
    else if(card_value == 5){
      value += "5 ";
    }
    else if(card_value == 6){
      value += "6 ";
    }
    else if(card_value == 7){
      value += "7 ";
    }
    else if(card_value == 8){
      value += "8 ";
    }
    else if(card_value == 9){
      value += "9 ";
    }
    else if(card_value == 10){
      value += "10 ";
    }
    return value + "of " + suit;
  }

  // equals method
  public boolean equals(Object o){
    if(!(o instanceof card)){
      return false;
    }
    card c = (card) o;
    return (this.card_value == c.card_value);
  }

  // mutators and accessors
  public int getValue(){
    return card_value;
  }
  public void setValue(int s_v){
    card_value = s_v;
  }
  public int getSuit(){
    return card_suit;
  }
  public void setSuit(int s_s){
    card_suit = s_s;
  }
}
