# ask player for their name
user_name = input("What is your name? ")
doorNum = input("Which direction do you want to go, " + user_name + " , 1, 2, 3, or 4? You can also press any other key to quit the program. ")
doors = ["1", "2", "3", "4"]
# valid door values
while doorNum in doors:
    # if statements for different door values
    if doorNum == "1":
        door_1 = input("Who is the current U.S. President? ")
        correct_answer = "Joe Biden"
        while True:
            if door_1 == correct_answer:
                print("You were correct! ")
                doorNum = input("Pick another door: ")
                break
            else:
                door_1 = input("That was incorrect, try again!" + " Or type 'next' to switch to another door: ")
                if door_1 == "next":
                    doorNum = input("Which direction do you want to go, " + user_name + " , 1, 2, 3, or 4? You can also press any other key to quit the program. ")
                    break
    elif doorNum == "2":
        door_2 = input("How many continents are there? ")
        correct_answer1 = "7"
        while True:
            if door_2 == "7":
                print("You were correct! ")
                doorNum = input("Pick another door: ")
                break
            else:
                door_2 = input("That was incorrect, try again!" + " Or type 'next' to switch to another door: ")
                if door_2 == "next":
                    doorNum = input("Which direction do you want to go, " + user_name + " , 1, 2, 3, or 4? You can also press any other key to quit the program. ")
                    break
    elif doorNum == "3":
        door_3 = input("How many countries are in North America? ")
        correct_answer2 = "3"
        while True:
            if door_3 == "3":
                print("You were correct! ")
                doorNum = input("Pick another door: ")
                break
            else:
                door_3 = input("That was incorrect, try again!" + " Or type 'next' to switch to another door: ")
                if door_3 == "next":
                    doorNum = input("Which direction do you want to go, " + user_name + " , 1, 2, 3, or 4? You can also press any other key to quit the program. ")
                    break
    elif doorNum == "4":
        door_4 = input("How many eggs are in 2 cartons of a dozen? ")
        correct_answer3 = "24"
        while True:
            if door_4 == "24":
                print("You were correct! ")
                doorNum = input("Pick another door: ")
                break
            else:
                door_4 = input("That was incorrect, try again!" + " Or type 'next' to switch to another door: ")
                if door_4 == "next":
                    doorNum = input("Which direction do you want to go, " + user_name + " , 1, 2, 3, or 4? You can also press any other key to quit the program. ")
                    break
else:
    print("That was not an option, goodbye!")
