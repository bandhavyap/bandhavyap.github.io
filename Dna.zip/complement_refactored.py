'''
STEPS
1. get user input for file
2. try to open in read mode and ask for new file name if invalid input
3. get all DNA strands from file
4. get comp + rev comp for each line
5. output results to file
'''
#DEFINING FUNCTIONS
def complement(DNA_strand):
    comp = ''
    DNA_strand = DNA_strand.upper()
    CompMap = {"A":"T","T":"A","C":"G","G":"C"}
    for letter in DNA_strand:
        comp += CompMap.get(letter, "*")
    return comp
def rev_complement(DNA_strand):
    comp = complement(DNA_strand)
    return comp[::-1]

# 1. get user input for file/ 2. try to open in read mode and ask for a new file name if invalid input
while True:
    try:
        user_file = input("Enter a file name: ")
        open_file = open(user_file, "r")
        break
    except:
        print("That isn't a valid file name please try again.")
# 3. get all DNA strands from file
input = open(user_file, "r")
output = open("results_complement.txt", "w")
for line in input:
    line = line.strip("\n")
    output.write(line)
    new_dna = complement(line) + "/"
    new_dna2 = rev_complement(line)
    output.write(new_dna)
    output.write(new_dna2)
    output.write("\n")
input.close()
output.close()
